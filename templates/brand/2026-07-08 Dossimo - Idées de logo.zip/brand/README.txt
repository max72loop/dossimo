DOSSIMO — KIT LOGO (encre monochrome)
=====================================

PALETTE
  Encre     #16202B   (texte principal, icône)
  Gris      #9AA1A9   (les deux « o »)
  Gris nuit #79828D   (les « o » sur fond sombre)
  Crème     #F3F0E9   (fond)
  Bleu lien #35507F   (liens sur le site — hors logo)

POLICE
  Unbounded 700 (logo) / 800 (icône).  https://fonts.google.com/specimen/Unbounded

FICHIERS
  dossimo-logo-encre.png    Lockup principal (encre + o gris), fond transparent
  dossimo-logo-encre.svg    Même lockup, vectoriel/éditable (police Unbounded requise)
  dossimo-logo-noir.png     Lockup 1 couleur, tout encre (impression / tampon)
  dossimo-logo-nuit.png     Lockup clair, pour fond sombre (transparent)
  dossimo-icon.png          Icône « d », tuile encre 512px (app / avatar)
  dossimo-icon-clair.png    Icône « d », tuile claire 512px
  favicon-512/32/16.png     Favicon aux 3 tailles
  signature-email.html      Signature prête à coller (logo embarqué, aucun hébergement)

FAVICON
  Utiliser favicon-512.png pour générer favicon.ico (ex. realfavicongenerator.net),
  ou déclarer directement :
    <link rel="icon" type="image/png" sizes="32x32" href="/favicon-32.png">
    <link rel="apple-touch-icon" href="/dossimo-icon.png">

ZONE DE PROTECTION
  Laisser autour du logo une marge >= la hauteur du « d ».

NOTE
  Dans la signature, « dossimo.app » est en encre (100 % monochrome).
  Pour le passer en bleu #35507F, changer color:#16202B dans le <a>.
